import './App.css';
import ProductTable from './homework';

function App() {
  return (
    <div className="App">
      <ProductTable />
    </div>
  );
}

export default App;
