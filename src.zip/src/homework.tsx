import React, { useState, useEffect } from 'react';
import './ProductTable.css'; // 引入CSS

// 定义数据类型
interface Product {
  id: string;
  name: string;
  category: string;
  status: 'wait' | 'processing' | 'completed' | 'cancelled' | 'delivery';
  price: number;
}

// 模拟数据
const mockData: Product[] = [
  { id: 'PROD001', name: '智能手机 S25', category: '电子产品', status: 'completed', price: 7999.00 },
  { id: 'PROD002', name: '高定西装', category: '服装', status: 'delivery', price: 2500.00 },
  { id: 'PROD003', name: 'React权威指南', category: '书籍', status: 'cancelled', price: 128.50 },
  { id: 'PROD004', name: '无线蓝牙耳机 Pro', category: '电子产品', status: 'completed', price: 999.00 },
  { id: 'PROD005', name: '夏季连衣裙', category: '服装', status: 'processing', price: 359.00 },
  { id: 'PROD006', name: '设计模式解析', category: '书籍', status: 'wait', price: 89.90 },
  { id: 'PROD007', name: '4K 超高清电视', category: '电子产品', status: 'completed', price: 5999.00 },
  { id: 'PROD008', name: '男士休闲裤', category: '服装', status: 'delivery', price: 280.00 },
  { id: 'PROD009', name: '前端开发实战', category: '书籍', status: 'completed', price: 150.00 },
  { id: 'PROD010', name: '智能手表 Ultra', category: '电子产品', status: 'wait', price: 2499.00 },
  { id: 'PROD011', name: '女士羊绒大衣', category: '服装', status: 'completed', price: 1800.00 },
  { id: 'PROD012', name: '算法导论（第三版）', category: '书籍', status: 'cancelled', price: 299.00 },
  { id: 'PROD013', name: '游戏笔记本 RTX4090', category: '电子产品', status: 'processing', price: 12999.00 },
  { id: 'PROD014', name: '儿童卡通T恤', category: '服装', status: 'delivery', price: 99.00 },
  { id: 'PROD015', name: '科幻小说集', category: '书籍', status: 'completed', price: 75.00 },
  { id: 'PROD016', name: '便携式移动电源', category: '电子产品', status: 'completed', price: 189.00 },
  { id: 'PROD017', name: '运动紧身裤', category: '服装', status: 'wait', price: 169.00 },
  { id: 'PROD018', name: '历史人文读本', category: '书籍', status: 'completed', price: 65.00 },
  { id: 'PROD019', name: '智能家居套装', category: '电子产品', status: 'cancelled', price: 3500.00 },
  { id: 'PROD020', name: '品牌休闲鞋', category: '服装', status: 'processing', price: 450.00 },
  { id: 'PROD021', name: '儿童绘本系列', category: '书籍', status: 'delivery', price: 55.00 },
  { id: 'PROD022', name: '高清网络摄像头', category: '电子产品', status: 'completed', price: 320.00 },
  { id: 'PROD023', name: '真丝睡衣套装', category: '服装', status: 'completed', price: 880.00 },
  { id: 'PROD024', name: '金融投资入门', category: '书籍', status: 'wait', price: 110.00 },
  { id: 'PROD025', name: '便携式投影仪', category: '电子产品', status: 'cancelled', price: 2999.00 }
];

const ProductTable: React.FC = () => {
  // 状态管理
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchName, setSearchName] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
    // 获取分类选项（去重）
  const categories = ['all', ...Array.from(new Set(mockData.map(item => item.category)))];
  // 获取状态选项
  const statusOptions = ['all', 'wait', 'processing', 'completed', 'cancelled'];

  // 初始化数据
  useEffect(() => {
    setProducts(mockData);
    setFilteredProducts(mockData);
  }, []);

  // 当筛选条件变化时自动更新
 useEffect(() => {
   const filterProducts = () => {
     let result = [...products];
    // 按名称筛选
     if (searchName) {
       result = result.filter(product => 
         product.name.toLowerCase().includes(searchName.toLowerCase())
       );
     }
    // 按分类筛选
     if (selectedCategory !== 'all') {
       result = result.filter(product => product.category === selectedCategory);
     }
    // 按状态筛选
     if (selectedStatus !== 'all') {
       result = result.filter(product => product.status === selectedStatus);
     }
    
     setFilteredProducts(result);
   };

  filterProducts();
}, [searchName, selectedCategory, selectedStatus, products]);

  // 重置筛选条件
  const resetFilters = () => {
    setSearchName('');
    setSelectedCategory('all');
    setSelectedStatus('all');
  };

  return (
    <div className="product-container">
      <h1 className="product-title">商品列表</h1>
      
      <div className="filter-form">
        <div className="filter-grid">
          <div className="filter-group">
            <label className="filter-label">名称</label>
            <input
              type="text"
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              className="filter-input"
              placeholder="输入商品名称"
            />
          </div>
          
          <div className="filter-group">
            <label className="filter-label">分类</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="filter-select"
            >
              {categories.map(category => (
                <option key={category} value={category}>
                  {category === 'all' ? '所有分类' : category}
                </option>
              ))}
            </select>
          </div>
          
          <div className="filter-group">
            <label className="filter-label">订单状态</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="filter-select"
            >
              {statusOptions.map(status => (
                <option key={status} value={status}>
                  {status === 'all' ? '所有状态' : 
                   status === 'wait' ? '待发货' :
                   status === 'processing' ? '待付款' :
                   status === 'delivery' ? '已发货' :
                   status === 'completed' ? '已完成' : '已取消'}
                </option>
              ))}
            </select>
          </div>
          
          <div className="filter-reset">
            <button
              onClick={resetFilters}
              className="reset-button"
            >
              重置筛选
            </button>
          </div>
        </div>
      </div>
      
      <div className="table-wrapper">
        <table className="product-table">
          <thead>
            <tr className="table-header">
              <th>ID</th>
              <th>名称</th>
              <th>分类</th>
              <th>订单状态</th>
              <th>价格</th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.length > 0 ? (
              filteredProducts.map(product => (
                <tr key={product.id} className="table-row">
                  <td className="text-center">{product.id}</td>
                  <td>{product.name}</td>
                  <td>{product.category}</td>
                  <td>
                    <span className={`status-badge ${
                      product.status === 'completed' ? 'status-completed' :
                      product.status === 'processing' ? 'status-processing' :
                      product.status === 'delivery' ? 'status-delivery' :
                      product.status === 'wait' ? 'status-wait' :
                      'status-cancelled'
                    }`}>
                      {product.status === 'wait' ? '待发货' :
                       product.status === 'processing' ? '待付款' :
                       product.status === 'delivery' ? '已发货' :
                       product.status === 'completed' ? '已完成' : '已取消'}
                    </span>
                  </td>
                  <td className="text-right">¥{product.price.toFixed(2)}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="no-data">
                  没有找到匹配的商品
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      <div className="data-count">
        共 {filteredProducts.length} 条数据
      </div>
    </div>
  );
};

export default ProductTable;